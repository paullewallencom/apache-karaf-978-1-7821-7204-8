
package com.your.organization;


import junit.framework.TestCase;

/**
 * Test cases for {@link CommandName}
 */
@SuppressWarnings("unchecked")
public class CommandNameTest extends TestCase {
    
    private CommandName command;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
    }
    
    @Override
    protected void tearDown() throws Exception {
        super.tearDown();
    }
    
	public void testCommand() {

	}
}
